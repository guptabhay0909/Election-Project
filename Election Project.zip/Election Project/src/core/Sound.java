/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;
import java.io.*;
import javax.swing.JOptionPane;
import sun.audio.*;
/**
 *
 * @author win10
 */
public class Sound {

    public InputStream in,out;
          public AudioStream correct;
          public AudioStream wrong;
    public Sound()
    {
          
        try{
            in=new FileInputStream(new File("E:\\Netbeans pc\\JavaApplication4\\src\\images\\correct_answer.wav"));
            out=new FileInputStream(new File("E:\\Netbeans pc\\JavaApplication4\\src\\images\\wrong_answer.wav"));
             correct= new AudioStream(in);
            wrong= new AudioStream(out);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
       
    }
     public void wrong1()
        {
            AudioPlayer.player.start(wrong);
        }
      public void correct1()
        {
            AudioPlayer.player.start(correct);
        }
}
