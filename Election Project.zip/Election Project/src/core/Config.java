package core;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import sun.audio.AudioPlayer;
public class Config {
     
    Sound obj= new Sound();
    public static int roll;
    public static boolean EnableSound= true;
    final public static ImageIcon logo=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\logo.jpg");
    
    final public String candidateBoy1 = "Aayush Gupt";
    final public String candidateBoy2 = "Parth Gupta";
    final public String candidateBoy3 = "Prashant Mishra";
    
    final public static ImageIcon CandidateBoy1i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateBoy1.jpg");
    final public static ImageIcon CandidateBoy2i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateBoy2.jpg");
    final public static ImageIcon CandidateBoy3i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateBoy3.jpg");
    
       
    final public String candidateGirl1 = "Kashika Gupta";
    final public String candidateGirl2 = "Antra Kashyap";
    final public String candidateGirl3 = "Shrinidhi Vasant";
    
    final public static ImageIcon CandidateGirl1i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateGirl1.jpg");
    final public static ImageIcon CandidateGirl2i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateGirl2.jpg");
    final public static ImageIcon CandidateGirl3i=new ImageIcon("E:\\Netbeans pc\\JavaApplication4\\src\\images\\candidateGirl3.jpg");
    
    final public String passcode = "1234";
    
    final public int[] Class6thA = {1001, 1038};    
    final public int[] Class6thB = {1051, 1088};
    final public int[] Class6thC = {1101, 1136};
    //6th Candidate over
    
    final public int[] Class7thA = {1151, 1191};
    final public int[] Class7thB = {1201, 1240};
    final public int[] Class7thC = {1251, 1290};
    //7th Candidate over
    
    final public int[] Class8thA = {1301, 1338};
    final public int[] Class8thB = {1351, 1388};
    final public int[] Class8thC = {1401, 1435};
    //8th Candidate over
    
    final public int[] Class9thA = {1451, 1487};
    final public int[] Class9thB = {1501, 1540};
    final public int[] Class9thC = {1551, 1589};
    //9th Candidate over
    
    final public int[] Class10thA = {1601, 1636};
    final public int[] Class10thB = {1651, 1680};
    final public int[] Class10thC = {1701, 1740};
    //10th Candidate over
    
    final public int[] Class11thA = {1751, 1796};
    final public int[] Class11thB = {1801, 1831};
    //11th Candidate over
    
    final public int[] Class12thA = {1851, 1877};
    final public int[] Class12thB = {1901, 1937};
    //12th Candidate over
    
    final public int[][] arrays = new int[][]{
                                                Class6thA, Class6thB, Class6thC, 
                                                Class7thA, Class7thB, Class7thC, 
                                                Class8thA, Class8thB, Class8thC,
                                                Class9thA, Class9thB,Class9thC,
                                                Class10thA, Class10thB, Class10thC,
                                                Class11thA, Class11thB,
                                                Class12thA, Class12thB
                                            };
    final public String[] classes = {
                                    "6th A", "6th B", "6th C", 
                                    "7th A", "7th B", "7th C", 
                                    "8th A", "8th B", "8th C", 
                                    "9th A", "9th B", "9th C", 
                                    "10th A", "10th B", "10th C", 
                                    "11th A", "11th B", 
                                    "12th A", "12th B"
                                };
    public String className(int a)
    {
        String classname=null;
    for(int i=0, count= arrays.length; i < count;i++)
    {
        if(a>=arrays[i][0] && arrays[i][1]>=a)
        {
            classname= classes[i];
        }
    }
    if(classname==null)
    {
        if(EnableSound)
        {
         obj.wrong1();
        }
         JOptionPane.showMessageDialog(null, "The Roll Number Does Not Exist");
    }
    
    
    return classname;
    
    }
}
